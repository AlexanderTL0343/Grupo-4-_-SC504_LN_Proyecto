<?php
define('HOST', 'localhost');
define('PORT', 1521);
define('NAME', 'xe');
define('USER', 'Proyecto');
define('PASS', '123');
?>